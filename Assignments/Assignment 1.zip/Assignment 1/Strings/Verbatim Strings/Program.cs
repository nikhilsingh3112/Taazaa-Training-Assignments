﻿using System;
  
public class GFG {
  
    // Main method
    static public void Main()
    {
  
        // Creating and initializing the array
        // here 'for' keyword is used as 
        // an identifier by using @ symbol
        string[] @for = {"C#", "PHP", "Java", "Python"};
  
                // as and for keywords is 
                // as an identifier
                // using @ symbol
                foreach (string @as in @for)
                {
                    Console.WriteLine("Element of Array: {0}", @as);
                }
    }
}