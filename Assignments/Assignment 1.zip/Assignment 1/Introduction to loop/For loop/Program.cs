﻿using System;   

public class forloopprog  

    {   

      public static void Main()   

      {   

          for(int i=1;i<=10;i++){     

            Console.WriteLine(i);     

          }     

      }   

    }   