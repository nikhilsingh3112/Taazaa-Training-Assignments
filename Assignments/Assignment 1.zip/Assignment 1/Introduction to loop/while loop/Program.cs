﻿using System; 

   

class whileloop 

{ 

    public static void Main() 

    { 

        int x = 1; 

        while (x <= 10) 

        { 

            Console.WriteLine("Ganesh"); 

            x++; 

        } 

    } 

} 